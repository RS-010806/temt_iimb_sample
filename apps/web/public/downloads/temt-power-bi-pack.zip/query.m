let
    CsvPath = "C:\TEMT\shipments.csv",
    Source = Csv.Document(File.Contents(CsvPath), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Types = Table.TransformColumnTypes(Headers, {{"date", type date}, {"legIndex", Int64.Type}, {"tonnes", type number}, {"kilometres", type number}, {"tonneKm", type number}, {"emissionsKg", type number}, {"emissionsTonnes", type number}, {"factorKgPerTonneKm", type number}}, "en-US")
in
    Types
