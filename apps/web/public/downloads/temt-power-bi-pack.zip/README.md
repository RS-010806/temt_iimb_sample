# TEMT Power BI data pack

This is an import-ready file pack, not a live Power BI connection.

Scenario: Illustrative India consumer group scenario
Data: SYNTHETIC. Not actual company performance.
Filters: {"mode":"all","subsidiary":"all","from":"2025-10-01","to":"2026-09-30"}
Calculation: local; engine temt-demo-1.0.0; 2026-09-13T20:09:04.257Z

## Import
1. Unzip this folder.
2. In Power BI Desktop select Get data > Text/CSV and choose shipments.csv.
3. Choose UTF-8 encoding, then Load. The table should be named Shipments.
4. Alternatively use query.m in a blank Power Query and update CsvPath to your local file.
5. Add the measures in measures.txt, one at a time.
6. Plot Date against Emissions (tCO2e), or Mode against Emissions (tCO2e).

The selected filters are already applied. Shipments with invalid legs are excluded as a whole before filtering. exceptions.csv contains every validation exception, full identifiers, source row numbers and original input rows. Summary counts cover the entire submitted input before filters, not just the current view. sourceRow is one-based; rowIndex is zero-based; csvLine assumes a one-line header. Excluded row and shipment counts are distinct counts, while validationExceptionCount counts exception records. A standalone CSV with no matching valid legs contains only a recordType=validation_summary metadata record; it is not a shipment. The ZIP shipments.csv remains header-only in that case.

## Calculation
Emissions kgCO2e = tonnes × kilometres × profile factor. Profiles and assumptions are included in factors.json. These are published factor-based illustrations. This demo is not the certified TEMT platform and does not issue assured reports. Road-to-rail scenarios hold tonne-kilometres constant and do not model rail access, capacity, routing or commercial feasibility.

Official TEMT: https://iimb.freightemissions.com/
DPIIT interface: https://dpiit.freightemissions.com/
SGS opinion: https://dpiit.freightemissions.com/certification.pdf
