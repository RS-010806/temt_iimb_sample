// Power Query (M). Home > Transform data > New source > Blank query > Advanced editor.
// Set FolderPath to the folder where you extracted this pack, then duplicate for each table.
let
    FolderPath = "C:\\TEMT\\",
    Source = Csv.Document(File.Contents(FolderPath & "fact_legs.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"date", type date}, {"leg_no", Int64.Type}, {"tonnes", type number}, {"distance_km", type number}, {"tonne_km", type number},
        {"ttw_kgco2e", type number}, {"wtt_kgco2e", type number}, {"wtw_kgco2e", type number}, {"intensity_gco2e_per_tkm", type number},
        {"factor_wtt", type number}, {"factor_ttw", type number}
    })
in
    Typed
