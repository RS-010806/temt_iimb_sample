# TEMT Power BI pack

Sample FMCG company (synthetic data) · FY 2025–26 · GLEC Framework v3.2 · India defaults · engine temt-engine-2.0.0

## Model
- **fact_legs**: one row per transport leg (emissions split TTW/WTT/WTW, tonne-km, factor, scope, data quality).
- **fact_hubs**: hub and terminal operations per shipment.
- **dim_shipments**: one row per shipment (reference, route, business unit, direction, who pays).
- **dim_date**: calendar with Indian financial year (April–March), fiscal quarter and month.
- **dim_mode**, **dim_factors**: lookup tables.

Relationships: fact_legs[shipment_ref] → dim_shipments[ref]; fact_hubs[shipment_ref] → dim_shipments[ref]; fact_legs[date] → dim_date[date]; fact_legs[mode] → dim_mode[mode].

## Steps
1. Extract this folder.
2. Power BI Desktop → Get data → Text/CSV → load each CSV (UTF-8). Or use fact_legs.pq in the Advanced editor and set FolderPath.
3. Model view → create the relationships above; mark dim_date as a date table.
4. Add the measures in measures.dax.
5. View → Themes → Browse for themes → report-theme.json for IIM Bangalore colours.

Emissions are reported in kg CO2e in the tables; the measures convert to tonnes. Figures follow ISO 14083:2023 and the GLEC Framework v3.2 on a well-to-wheel basis.
